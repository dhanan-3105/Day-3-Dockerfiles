#!/bin/bash
echo "Restarting the service ..."
sleep 5
exit 1
